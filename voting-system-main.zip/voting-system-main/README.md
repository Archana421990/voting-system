# voting-system
Here I am going to add 3 types of voting system, for now I have put simple application for Voting system


METHOD1: Simple Voting System [Click Here](https://github.com/Archana421990/voting-system/releases/download/v0.1/index.exe)
